# Mekanism NeoForge MC 26.3 port notes

## Status
**BUILD SUCCESSFUL** (JDK `E:\java 25`)

## Base
- Required download kept: `../Mekanism-v1.21.1-10.7.19.85.zip` (tag `v1.21.1-10.7.19.85`)
- Working tree: official Mekanism `26.3` branch (this folder), upstream port 1.21.1 → 26.3, then customized

## Versions
- Minecraft: `26.3`
- NeoForge: `26.3.0.7-beta`
- Java: `25` (`E:\java 25`)
- Mod version: `10.8.0.homebaked`

## New feature
On player login (`PlayerEvent.PlayerLoggedInEvent`), send one system chat line:

`[Mekanism] портировал entiti937`

- File: `src/main/java/mekanism/common/CommonPlayerTracker.java`
- Hook: `onPlayerLoginEvent` → `player.sendSystemMessage(PORT_CREDIT)`

## Artifacts
`build/libs/`:
- `Mekanism-26.3-10.8.0.homebaked.jar` (main)
- `Mekanism-26.3-10.8.0.homebaked-all.jar`
- `MekanismAdditions-26.3-10.8.0.homebaked.jar`
- `MekanismGenerators-26.3-10.8.0.homebaked.jar`
- `MekanismTools-26.3-10.8.0.homebaked.jar`

## How to test
1. Install NeoForge `26.3.0.7-beta` for Minecraft `26.3`
2. Drop the main (+ optional module) jars into `mods/`
3. Join a world — chat should show: `[Mekanism] портировал entiti937`

## Build notes
- Optional integrations (JEI/Jade/TOP/etc.) disabled for a cleaner 26.3 compile
- `recipe_viewer=none`
