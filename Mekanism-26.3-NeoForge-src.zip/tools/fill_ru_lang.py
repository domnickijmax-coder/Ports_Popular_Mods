# -*- coding: utf-8 -*-
"""Fill missing ru_ru.json keys from en_us using the existing Mekanism glossary plus new terms."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

PAIRS = [
    (ROOT / "src/datagen/generated/mekanism/assets/mekanism/lang/en_us.json",
     ROOT / "src/main/resources/assets/mekanism/lang/ru_ru.json"),
    (ROOT / "src/datagen/generated/mekanismadditions/assets/mekanismadditions/lang/en_us.json",
     ROOT / "src/additions/resources/assets/mekanismadditions/lang/ru_ru.json"),
    (ROOT / "src/datagen/generated/mekanismgenerators/assets/mekanismgenerators/lang/en_us.json",
     ROOT / "src/generators/resources/assets/mekanismgenerators/lang/ru_ru.json"),
    (ROOT / "src/datagen/generated/mekanismtools/assets/mekanismtools/lang/en_us.json",
     ROOT / "src/tools/resources/assets/mekanismtools/lang/ru_ru.json"),
]

# Longer phrases first. Applied before single words.
PHRASES = [
    ("Pressurized Tubes", "трубы под давлением"),
    ("Mechanical Pipes", "механические трубы"),
    ("Logistical Transporters", "логистические транспортёры"),
    ("Thermodynamic Conductors", "термодинамические проводники"),
    ("Universal Cables", "универсальные кабели"),
    ("Chemical Tanks", "химические баки"),
    ("Fluid Tanks", "жидкостные баки"),
    ("Chemical Tank", "химический бак"),
    ("Fluid Tank", "жидкостный бак"),
    ("Chemical Crystallizer", "химический кристаллизатор"),
    ("Chemical Dissolution Chamber", "камера химического растворения"),
    ("Chemical Injection Chamber", "камера химического впрыска"),
    ("Chemical Infuser", "химический нагнетатель"),
    ("Chemical Oxidizer", "химический окислитель"),
    ("Chemical Washer", "химическая промывка"),
    ("Metallurgic Infuser", "металлургический нагнетатель"),
    ("Pigment Extractor", "экстрактор пигмента"),
    ("Pigment Mixer", "смеситель пигмента"),
    ("Fluidic Plenisher", "жидкостный наполнитель"),
    ("Electric Pump", "электрический насос"),
    ("Radioactive Waste Barrel", "бочка радиоактивных отходов"),
    ("Digital Miner", "цифровой шахтёр"),
    ("Heat Generator", "тепловой генератор"),
    ("Advanced Solar Generator", "продвинутый солнечный генератор"),
    ("Solar Generator", "солнечный генератор"),
    ("Wind Generator", "ветряной генератор"),
    ("Bio Generator", "биогенератор"),
    ("Fuelwood Heater", "дровяной нагреватель"),
    ("Fusion Reactor", "термоядерный реактор"),
    ("Fission Reactor", "ядерный реактор деления"),
    ("Evaporation Plant", "испарительная установка"),
    ("Pressurized Tube", "труба под давлением"),
    ("Mechanical Pipe", "механическая труба"),
    ("Heavy Water", "тяжёлая вода"),
    ("Gaseous Brine", "газообразный рассол"),
    ("Hydrofluoric Acid", "плавиковая кислота"),
    ("Sulfuric Acid", "серная кислота"),
    ("Sulfur Dioxide", "диоксид серы"),
    ("Sulfur Trioxide", "триоксид серы"),
    ("Hydrogen Chloride", "хлористый водород"),
    ("Uranium Hexafluoride", "гексафторид урана"),
    ("Uranium Oxide", "оксид урана"),
    ("Nuclear Waste", "ядерные отходы"),
    ("Spent Nuclear Waste", "отработанные ядерные отходы"),
    ("Fissile Fuel", "делящееся топливо"),
    ("Superheated Sodium", "перегретый натрий"),
    ("Water Vapor", "водяной пар"),
    ("Clean Slurry", "очищенная взвесь"),
    ("Dirty Slurry", "грязная взвесь"),
    ("Infused Alloy", "насыщенный сплав"),
    ("Infused Alloys", "насыщенные сплавы"),
    ("Refined Obsidian", "очищенный обсидиан"),
    ("Refined Glowstone", "очищенный светокамень"),
    ("Lapis Lazuli", "лазурит"),
    ("Redstone", "редстоун"),
    ("Control Circuit", "схема управления"),
    ("Advanced Alloys", "продвинутые сплавы"),
    ("Advanced Circuits", "продвинутые схемы"),
    ("Antimatter Pellets", "гранулы антиматерии"),
    ("Output Rate", "скорость вывода"),
    ("Pull Rate", "скорость забора"),
    ("Transfer Speed", "скорость передачи"),
    ("Energy Capacity", "ёмкость энергии"),
    ("Energy Usage", "потребление энергии"),
    ("Fill Rate", "скорость заполнения"),
    ("Chemical Rate", "скорость химикатов"),
    ("Fluid Rate", "скорость жидкости"),
    ("Chemical Buffer", "буфер химикатов"),
    ("Fluid Buffer", "буфер жидкости"),
    ("Stored Chemicals", "запасённые химикаты"),
    ("Stored Liquids", "запасённые жидкости"),
    ("No chemicals stored", "химикаты не запасены"),
    ("Item to Chemical", "предмет в химикат"),
    ("Alpha Warning", "предупреждение об альфе"),
    ("Allow Chunkloading", "разрешить загрузку чанков"),
    ("MekaSuit", "Мекакостюм"),
    ("Jetpack", "реактивный ранец"),
    ("Free Runners", "скороходы"),
    ("Armored Jetpacks", "бронированные реактивные ранцы"),
    ("Armored Free Runners", "бронированные скороходы"),
    ("BodyArmor", "нагрудник"),
    ("mB/t", "мБ/т"),
]

# Short tokens must not match inside words (mB was eating the "mb" in "assemblies").
SHORT_TOKENS = [
    (re.compile(r"\bmB\b"), "мБ"),
    (re.compile(r"\bFE\b"), "FE"),
]

WORDS = {
    "a": "", "an": "", "the": "", "of": "", "to": "", "be": "", "is": "", "are": "", "was": "", "were": "",
    "but": "но", "whole": "целый",
    "that": "который", "this": "этот", "these": "эти", "those": "", "and": "и", "or": "или", "nor": "ни",
    "with": "с", "from": "из", "into": "в", "onto": "на", "in": "в", "on": "на", "at": "при", "by": "",
    "for": "для", "per": "за", "as": "как", "if": "если", "when": "когда", "while": "пока", "whilst": "пока",
    "than": "чем", "then": "затем", "not": "не", "no": "нет", "yes": "", "all": "все", "any": "любой",
    "each": "каждый", "every": "каждый", "some": "некоторые", "other": "другой", "others": "другие",
    "its": "его", "their": "их", "them": "их", "they": "они", "it": "это", "you": "вы", "your": "ваш",
    "we": "мы", "our": "", "can": "может", "can't": "не может", "cannot": "не может", "will": "будет",
    "would": "бы", "should": "должен", "must": "должен", "may": "может", "do": "", "does": "", "don't": "не",
    "won't": "не будет", "has": "имеет", "have": "имеют", "having": "имея", "been": "", "being": "",
    "also": "также", "only": "только", "just": "просто", "even": "даже", "still": "всё ещё", "more": "больше",
    "most": "наиболее", "less": "меньше", "much": "много", "many": "много", "very": "очень", "too": "слишком",
    "so": "так", "such": "такой", "both": "оба", "either": "либо", "whether": "ли", "how": "как",
    "what": "что", "which": "который", "who": "кто", "where": "где", "there": "там", "here": "здесь",
    "up": "вверх", "down": "вниз", "out": "наружу", "off": "выкл", "over": "над", "under": "под",
    "between": "между", "after": "после", "before": "до", "during": "во время", "without": "без",
    "within": "в пределах", "about": "около", "around": "вокруг", "across": "через", "through": "через",
    "above": "выше", "below": "ниже", "near": "рядом", "far": "далеко", "back": "назад", "next": "следующий",
    "new": "новый", "old": "старый", "same": "тот же", "different": "другой", "own": "свой",
    "able": "способный", "above": "выше", "absent": "отсутствует", "absorb": "поглощать", "absorbed": "поглощено",
    "absorption": "поглощение", "abuse": "злоупотребление", "accept": "принимать", "accessing": "доступ",
    "accidental": "случайный", "account": "учёт", "acid": "кислота", "acquire": "получить", "action": "действие",
    "activate": "активировать", "activating": "активация", "activator": "активатор", "active": "активный",
    "actively": "активно", "actually": "на самом деле", "add": "добавить", "added": "добавлено", "adding": "добавление",
    "additional": "дополнительный", "additions": "дополнения", "adds": "добавляет", "adjacent": "соседний",
    "adjust": "настроить", "adjusting": "настройка", "adult": "взрослый", "advanced": "продвинутый",
    "aesthetic": "декоративный", "affect": "влиять", "affects": "влияет", "air": "воздух", "algorithm": "алгоритм",
    "allow": "разрешить", "allowing": "позволяя", "allows": "позволяет", "alloy": "сплав", "alloys": "сплавы",
    "alpha": "альфа", "always": "всегда", "ambient": "окружающий", "amount": "количество", "anchor": "якорь",
    "angle": "угол", "antimatter": "антиматерия", "aoe": "область", "apart": "на части", "applied": "применён",
    "area": "область", "armor": "броня", "armoured": "бронированный", "armored": "бронированный",
    "array": "массив", "ascending": "по возрастанию", "assemblicator": "сборщик", "assemblies": "сборки",
    "assembly": "сборка", "assumes": "предполагает", "atomic": "атомный", "attack": "атака", "attacked": "атакован",
    "attacking": "атака", "attacks": "атаки", "attempt": "попытка", "attempts": "попытки", "attract": "притягивать",
    "attraction": "притяжение", "auto": "авто", "automatically": "автоматически", "average": "средний",
    "baby": "детёныш", "balloons": "шары", "banners": "флаги", "bar": "полоса", "barrel": "бочка",
    "base": "база", "based": "на основе", "basic": "базовый", "beacons": "маяки", "beds": "кровати",
    "behavior": "поведение", "behaviours": "поведения", "behaviors": "поведения", "bers": "",
    "bin": "контейнер", "bins": "контейнеры", "bio": "био", "biofuel": "биотопливо", "blacklist": "чёрный список",
    "block": "блок", "blocked": "заблокирован", "blocking": "блокирование", "blocks": "блоки",
    "bodyarmor": "нагрудник", "bogged": "болотник", "boil": "кипение", "boiler": "котёл", "boilers": "котлы",
    "bolts": "болты", "bonus": "бонус", "boots": "ботинки", "bow": "лук", "box": "коробка", "boxes": "коробки",
    "break": "ломать", "brine": "рассол", "broken": "сломан", "bronze": "бронза", "bucket": "ведро",
    "buckets": "вёдра", "buffer": "буфер", "bump": "увеличить", "buried": "погребённый", "burn": "сжигание",
    "burning": "горение", "burns": "сжигает", "button": "кнопка", "bypass": "обход", "cable": "кабель",
    "cables": "кабели", "calculate": "вычислять", "calculated": "вычислено", "calculating": "вычисление",
    "calculations": "расчёты", "candles": "свечи", "canteen": "фляга", "canteens": "фляги", "capable": "способный",
    "capacity": "ёмкость", "cardboard": "картон", "carpets": "ковры", "case": "случай", "casing": "корпус",
    "catastrophic": "катастрофический", "cause": "причина", "causing": "вызывая", "cavity": "полость",
    "cells": "ячейки", "centrifuge": "центрифуга", "centrifuging": "центрифугирование", "certain": "определённый",
    "chamber": "камера", "chambers": "камеры", "chance": "шанс", "change": "изменение", "changes": "изменения",
    "charcoal": "древесный уголь", "charge": "заряд", "charging": "зарядка", "check": "проверка",
    "checked": "проверено", "chemical": "химикат", "chemicals": "химикаты", "chests": "сундуки",
    "chloride": "хлорид", "chlorine": "хлор", "christmas": "рождество", "chunk": "чанк",
    "chunkloading": "загрузка чанков", "chunks": "чанки", "circuits": "схемы", "click": "щелчок",
    "clicking": "нажатие", "client": "клиент", "closed": "закрыто", "clumps": "скопления", "coal": "уголь",
    "color": "цвет", "colorable": "окрашиваемый", "combiner": "объединитель", "common": "обычный",
    "compared": "по сравнению", "completely": "полностью", "component": "компонент", "compressing": "сжатие",
    "compressor": "компрессор", "concrete": "бетон", "condensation": "конденсация", "condensed": "сгущённый",
    "condensentrator": "конденсатор", "conduction": "проводимость", "conductivity": "теплопроводность",
    "conductor": "проводник", "conductors": "проводники", "config": "конфиг", "configuration": "конфигурация",
    "configurators": "конфигураторы", "configuring": "настройка", "confirmation": "подтверждение",
    "consider": "учитывать", "considered": "считается", "constant": "постоянный", "consume": "потреблять",
    "consumed": "потреблено", "contains": "содержит", "contents": "содержимое", "continues": "продолжается",
    "contributes": "даёт", "controls": "управляет", "conversion": "преобразование", "conversions": "преобразования",
    "convert": "преобразовать", "converted": "преобразовано", "converting": "преобразование", "cool": "охлаждать",
    "coolant": "хладагент", "cooldown": "перезарядка", "cooled": "охлаждённый", "cooling": "охлаждение",
    "copied": "скопировано", "copper": "медь", "copy": "копия", "cost": "стоимость", "count": "число",
    "counter": "счётчик", "crafting": "крафт", "crazy": "безумный", "create": "создать", "created": "создано",
    "creates": "создаёт", "creative": "творческий", "creeper": "крипер", "critical": "критический",
    "crusher": "дробитель", "crushing": "дробление", "crystallizer": "кристаллизатор",
    "crystallizing": "кристаллизация", "crystals": "кристаллы", "cubes": "кубы", "currently": "сейчас",
    "damage": "урон", "damaging": "урон", "dashboard": "панель", "data": "данные", "deactivation": "деактивация",
    "dealt": "нанесённый", "debarking": "окорка", "debug": "отладка", "decay": "распад", "default": "по умолчанию",
    "defaults": "значения по умолчанию", "define": "задать", "defined": "заданный", "defines": "задаёт",
    "degree": "градус", "delay": "задержка", "density": "плотность", "descending": "по убыванию",
    "destination": "назначение", "destroy": "уничтожить", "details": "подробности", "detected": "обнаружено",
    "determines": "определяет", "dev": "разработка", "diamond": "алмаз", "digital": "цифровой",
    "dimension": "измерение", "dimensional": "пространственный", "dioxide": "диоксид", "direction": "направление",
    "directly": "напрямую", "dirty": "грязный", "disable": "отключить", "disabled": "отключено",
    "disabling": "отключение", "disassembler": "разборщик", "discard": "отбросить", "dismount": "сбрасывание",
    "dispersed": "рассеянный", "dispersion": "рассеяние", "display": "отображение", "displayed": "показано",
    "displays": "показывает", "dissipated": "рассеяно", "dissipation": "рассеяние", "dissolution": "растворение",
    "distance": "дистанция", "distribution": "распределение", "divided": "делено", "divisor": "делитель",
    "dmg": "урон", "dosage": "доза", "dosimeter": "дозиметр", "dragging": "перетаскивание", "drain": "откачивать",
    "dropper": "выбрасыватель", "droppers": "выбрасыватели", "due": "из-за", "dumping": "сброс",
    "durability": "прочность", "duration": "длительность", "dusts": "пыль", "dynamic": "динамический",
    "easter": "пасха", "easy": "лёгкий", "eaten": "съедено", "edit": "изменить", "effect": "эффект",
    "effectively": "фактически", "effectiveness": "эффективность", "effects": "эффекты", "efficiency": "КПД",
    "efficient": "эффективный", "egg": "яйцо", "eggs": "яйца", "eject": "выброс", "ejected": "выброшено",
    "ejection": "выброс", "electric": "электрический", "electrolysis": "электролиз", "electrolytic": "электролизный",
    "element": "элемент", "elements": "элементы", "elite": "элитный", "elytra": "элитры", "emerald": "изумруд",
    "emission": "излучение", "emptied": "опустошено", "enable": "включить", "enabled": "включено",
    "enables": "включает", "enabling": "включение", "enchantability": "зачаровываемость", "end": "край",
    "enderman": "эндермен", "energized": "заряженный", "energy": "энергия", "enough": "достаточно",
    "enriched": "обогащённый", "enriching": "обогащение", "enrichment": "обогащение", "ensure": "гарантировать",
    "entangloporter": "квантовый портал", "entangloporters": "квантовые порталы", "entities": "сущности",
    "entity": "сущность", "entry": "запись", "environments": "среды", "equal": "равный", "equates": "равно",
    "equipped": "экипировано", "equivalent": "эквивалент", "escape": "побег", "escaping": "побег",
    "ethene": "этен", "ethylene": "этилен", "evaporating": "испарение", "evaporation": "испарение",
    "everything": "всё", "example": "пример", "excess": "избыток", "expected": "ожидаемый",
    "explicitly": "явно", "explosion": "взрыв", "exposed": "открытый", "extend": "расширить",
    "extended": "расширенный", "extracted": "извлечено", "extracting": "извлечение", "extractor": "экстрактор",
    "extreme": "экстремальный", "facing": "сторона", "factor": "множитель", "fails": "не удаётся",
    "fall": "падение", "falling": "падение", "false": "ложь", "fast": "быстрый", "faster": "быстрее",
    "featuring": "с", "fence": "забор", "fences": "заборы", "fill": "заполнение", "filled": "заполненный",
    "filter": "фильтр", "filters": "фильтры", "fire": "огонь", "fires": "выстрелы", "first": "первый",
    "fissile": "делящийся", "fission": "деление", "fit": "подходить", "five": "пять", "flame": "пламя",
    "flamethrower": "огнемёт", "flat": "плоский", "flow": "поток", "fluid": "жидкость", "fluidic": "жидкостный",
    "fluids": "жидкости", "fluorite": "флюорит", "focus": "фокус", "focused": "сфокусированный", "food": "еда",
    "force": "сила", "form": "форма", "formation": "формация", "forms": "формы", "formulaic": "формульный",
    "fraction": "доля", "framed": "обрамлённый", "free": "свободный", "frequencies": "частоты",
    "frequency": "частота", "fuel": "топливо", "fuels": "топлива", "fuelwood": "дрова", "full": "полный",
    "functionality": "функции", "fuse": "плавка", "fused": "сплавлен", "fusion": "синтез", "game": "игра",
    "gas": "газ", "gates": "ворота", "gateways": "шлюзы", "gauge": "индикатор", "gear": "снаряжение",
    "geiger": "гейгер", "general": "общее", "generate": "генерировать", "generated": "сгенерировано",
    "generates": "генерирует", "generating": "генерация", "generation": "генерация", "generator": "генератор",
    "generators": "генераторы", "generic": "обычный", "geothermal": "геотермальный", "gets": "получает",
    "give": "дать", "glass": "стекло", "glow": "свечение", "glowstone": "светокамень", "go": "идти",
    "gold": "золото", "gravitational": "гравитационный", "greater": "больше", "greetings": "приветствия",
    "grid": "сеть", "group": "группа", "guess": "видимо", "half": "половина", "handheld": "ручной",
    "handling": "обработка", "harder": "сложнее", "hardness": "твёрдость", "heart": "сердце", "hearts": "сердца",
    "heat": "тепло", "heated": "нагретый", "heater": "нагреватель", "heaters": "нагреватели",
    "heating": "нагрев", "heavy": "тяжёлый", "height": "высота", "helmet": "шлем", "helmets": "шлемы",
    "help": "помощь", "hexafluoride": "гексафторид", "high": "высокий", "higher": "выше", "highly": "очень",
    "hits": "удары", "holiday": "праздник", "holidays": "праздники", "hopefully": "надеемся",
    "horizontal": "горизонтальный", "horizontally": "горизонтально", "hours": "часы", "hydrofluoric": "плавиковый",
    "hydrogen": "водород", "hydrostatic": "гидростатический", "id": "ID", "ignition": "зажигание",
    "illegal": "недопустимый", "immediately": "сразу", "impact": "удар", "inactive": "неактивный",
    "incinerated": "сожжён", "include": "включать", "includes": "включает", "inclusive": "включительно",
    "incoming": "входящий", "increase": "увеличить", "increases": "увеличивает", "increasing": "увеличение",
    "induction": "индукция", "industrial": "промышленный", "infinite": "бесконечный", "infused": "насыщенный",
    "infuser": "нагнетатель", "infusing": "насыщение", "ingots": "слитки", "injecting": "впрыск",
    "injection": "впрыск", "injectors": "инжекторы", "inner": "внутренний", "input": "вход", "inputs": "входы",
    "inserted": "вставлено", "installed": "установлено", "instance": "экземпляр", "instead": "вместо",
    "insulation": "изоляция", "interdimensional": "межпространственный", "invalid": "неверный",
    "inventory": "инвентарь", "inverse": "обратный", "iron": "железо", "isotopic": "изотопный",
    "issues": "проблемы", "item": "предмет", "items": "предметы", "itself": "сам", "jab": "укол",
    "jetpack": "реактивный ранец", "jetpacks": "реактивные ранцы", "joining": "вход", "joules": "джоули",
    "knock": "отброс", "knockback": "отбрасывание", "known": "известный", "lag": "лаги", "lapis": "лазурит",
    "large": "большой", "laser": "лазер", "lasers": "лазеры", "last": "последний", "lava": "лава",
    "layers": "слои", "lazuli": "лазурит", "lead": "свинец", "least": "минимум", "leave": "оставить",
    "length": "длина", "level": "уровень", "levels": "уровни", "life": "жизнь", "like": "как",
    "likely": "вероятно", "limited": "ограниченный", "linearly": "линейно", "liquid": "жидкость",
    "liquids": "жидкости", "liquifier": "сжижитель", "list": "список", "listen": "слушать", "lithium": "литий",
    "load": "загрузка", "loaded": "загружено", "located": "расположен", "log": "бревно", "logged": "залит",
    "logging": "заполнение", "logistical": "логистический", "logs": "брёвна", "loss": "потеря",
    "louder": "громче", "lower": "ниже", "lowering": "снижение", "machine": "машина", "machinery": "механизмы",
    "machines": "машины", "magic": "магия", "magnetic": "магнитный", "make": "сделать", "makes": "делает",
    "making": "создание", "manually": "вручную", "map": "карта", "maps": "сопоставляет", "mask": "маска",
    "material": "материал", "materials": "материалы", "matrix": "матрица", "max": "макс", "maximum": "максимум",
    "means": "означает", "mechanical": "механический", "mek": "мек", "meka": "мека", "mekanism": "Mekanism",
    "mekasuit": "Мекакостюм", "meltdown": "расплавление", "meltdowns": "расплавления", "melting": "плавление",
    "memory": "память", "message": "сообщение", "metallurgic": "металлургический", "middle": "середина",
    "min": "мин", "mine": "добывать", "minecraft": "Minecraft", "miner": "шахтёр", "minimizing": "уменьшение",
    "minimum": "минимум", "mining": "добыча", "miscellaneous": "разное", "missing": "отсутствует",
    "mixer": "смеситель", "mixture": "смесь", "mob": "моб", "mobs": "мобы", "mod": "мод", "mode": "режим",
    "modids": "идентификаторы модов", "modification": "модификация", "modified": "изменённый",
    "modifier": "модификатор", "modulating": "модуляция", "modulation": "модуляция", "module": "модуль",
    "modules": "модули", "moved": "перемещено", "muffling": "глушение", "multiblock": "мультиблок",
    "multiblocks": "мультиблоки", "multiplied": "умножено", "multiplier": "множитель", "multiply": "умножить",
    "name": "имя", "names": "имена", "natural": "естественный", "nearest": "ближайший", "necessary": "нужный",
    "needed": "нужно", "negated": "инвертировано", "negative": "отрицательный", "neither": "ни",
    "nether": "Незер", "netherite": "незерит", "network": "сеть", "neutron": "нейтрон", "never": "никогда",
    "nodes": "узлы", "non": "не", "normal": "обычный", "normally": "обычно", "note": "примечание",
    "notification": "уведомление", "nucleosynthesizer": "нуклеосинтезатор",
    "nucleosynthesizing": "нуклеосинтез", "nuggets": "самородки", "number": "число", "nutritional": "питательный",
    "objects": "объекты", "oblivion": "небытие", "obsidian": "обсидиан", "occur": "происходить",
    "occurring": "происходящий", "occurs": "происходит", "once": "один раз", "one": "один", "ones": "те",
    "opaque": "непрозрачный", "open": "открыть", "opened": "открыто", "operation": "операция",
    "operator": "оператор", "ops": "операторы", "option": "параметр", "options": "параметры",
    "ore": "руда", "oredictionificator": "словарный преобразователь", "ores": "руды", "osmium": "осмий",
    "otherwise": "иначе", "output": "выход", "oxide": "оксид", "oxidizer": "окислитель", "oxidizing": "окисление",
    "oxygen": "кислород", "packet": "пакет", "painting": "картина", "panel": "панель", "panels": "панели",
    "panes": "панели", "pants": "поножи", "parched": "иссушённый", "particle": "частица", "particles": "частицы",
    "pass": "проходить", "passed": "пройдено", "passes": "проходит", "paste": "паста", "paxel": "паксель",
    "paxels": "паксели", "peak": "пик", "pellets": "гранулы", "penalty": "штраф", "percent": "процент",
    "percentage": "процент", "perform": "выполнять", "performance": "производительность", "performed": "выполнено",
    "performing": "выполнение", "permission": "разрешение", "pertaining": "относящийся", "phase": "фаза",
    "picked": "подобран", "pigment": "пигмент", "pinned": "закреплено", "pipe": "труба", "pipes": "трубы",
    "place": "место", "placed": "установлен", "placement": "размещение", "placing": "размещение",
    "plant": "установка", "plants": "установки", "plastic": "пластик", "plateau": "плато", "play": "играть",
    "player": "игрок", "players": "игроки", "playing": "воспроизведение", "please": "пожалуйста",
    "plenisher": "наполнитель", "plenishers": "наполнители", "plutonium": "плутоний", "polonium": "полоний",
    "port": "порт", "portable": "портативный", "portion": "часть", "position": "позиция", "post": "после",
    "potentially": "потенциально", "potion": "зелье", "powders": "порошки", "power": "мощность",
    "powerful": "мощный", "precision": "точность", "prefilled": "предзаполненный", "prefixes": "префиксы",
    "present": "присутствует", "pressurized": "под давлением", "prevent": "предотвращать",
    "prevention": "предотвращение", "prevents": "предотвращает", "process": "процесс", "processes": "процессы",
    "processing": "обработка", "processor": "процессор", "produce": "производить", "produced": "произведено",
    "produces": "производит", "product": "продукт", "protection": "защита", "provide": "дать",
    "providers": "источники", "provides": "даёт", "pull": "забор", "pulling": "забор", "pulse": "импульс",
    "pump": "насос", "pumps": "насосы", "purification": "очистка", "purifying": "очищение", "qio": "QIO",
    "quantum": "квантовый", "quartz": "кварц", "radiated": "облучённый", "radiation": "радиация",
    "radioactive": "радиоактивный", "radioactivity": "радиоактивность", "radius": "радиус", "raise": "поднять",
    "randomized": "случайный", "range": "диапазон", "rapid": "быстрый", "rate": "скорость", "rates": "скорости",
    "ratio": "соотношение", "ratios": "соотношения", "reach": "достигать", "reached": "достигнуто",
    "reaction": "реакция", "reactor": "реактор", "reactors": "реакторы", "reader": "считыватель",
    "readers": "считыватели", "readings": "показания", "received": "получено", "recipe": "рецепт",
    "recipes": "рецепты", "recommend": "рекомендовать", "recommended": "рекомендуется",
    "reconstructed": "восстановлено", "red": "красный", "redstone": "редстоун", "reduction": "снижение",
    "refined": "очищенный", "regarding": "относительно", "regardless": "независимо", "regen": "реген",
    "registered": "зарегистрированный", "registry": "реестр", "reinforced": "усиленный", "rejects": "отклоняет",
    "relating": "связанный", "relative": "относительный", "remainder": "остаток", "remove": "убрать",
    "removed": "убрано", "rename": "переименовать", "render": "отрисовка", "renderers": "отрисовщики",
    "rendering": "отрисовка", "renders": "рисует", "reopened": "открыто снова", "replacing": "замена",
    "represent": "представлять", "repulsion": "отталкивание", "require": "требовать", "required": "требуется",
    "requires": "требует", "resistance": "сопротивление", "resistive": "резистивный",
    "restrictions": "ограничения", "retrogen": "ретрогенерация", "returned": "возвращено", "right": "правый",
    "roads": "дороги", "robits": "робиты", "rods": "стержни", "rotary": "роторный", "roughly": "примерно",
    "rounded": "округлённый", "rule": "правило", "runner": "скороход", "runners": "скороходы",
    "running": "работа", "ruthlessly": "безжалостно", "safe": "безопасный", "salt": "соль", "salts": "соли",
    "saturation": "насыщение", "sawdusts": "опилки", "sawing": "распил", "sawmill": "лесопилка",
    "scale": "масштаб", "scaled": "масштабировано", "scales": "масштабы", "scuba": "акваланг",
    "sculk": "скалк", "search": "поиск", "second": "секунда", "secondary": "вторичный", "seconds": "секунды",
    "security": "безопасность", "seismic": "сейсмический", "select": "выбрать", "selecting": "выбор",
    "semi": "полу", "sensors": "датчики", "separator": "сепаратор", "server": "сервер", "set": "набор",
    "setting": "параметр", "settings": "настройки", "severity": "тяжесть", "shape": "форма",
    "shards": "осколки", "shear": "стрижка", "shield": "щит", "shields": "щиты", "shifted": "смещён",
    "shifter": "сдвигатель", "short": "короткий", "show": "показать", "shriekers": "крикуны",
    "side": "сторона", "sides": "стороны", "signal": "сигнал", "silk": "шёлк", "similarly": "аналогично",
    "single": "один", "size": "размер", "skeleton": "скелет", "skin": "скин", "slab": "плита",
    "slabs": "плиты", "slick": "скользкий", "slot": "слот", "slots": "слоты", "slow": "медленный",
    "small": "малый", "smelt": "плавить", "smelter": "плавильня", "smelting": "плавка", "sodium": "натрий",
    "softer": "тише", "solar": "солнечный", "solid": "твёрдый", "sort": "сортировка", "sorting": "сортировка",
    "sound": "звук", "sounds": "звуки", "source": "источник", "sources": "источники", "sparkles": "искры",
    "spawn": "спавн", "spawning": "спавн", "spawns": "спавны", "spear": "копьё", "spears": "копья",
    "special": "особый", "specific": "конкретный", "speed": "скорость", "speedup": "ускорение",
    "split": "разделить", "spread": "разброс", "sps": "SPS", "stability": "стабильность",
    "stabilizer": "стабилизатор", "stack": "стак", "stairs": "ступени", "start": "старт", "started": "запущено",
    "startup": "запуск", "state": "состояние", "station": "станция", "steam": "пар", "steel": "сталь",
    "stone": "камень", "stopping": "остановка", "stops": "останавливает", "storable": "хранимый",
    "storage": "хранилище", "store": "хранить", "stored": "запасённый", "stores": "хранит",
    "strategy": "стратегия", "stray": "скелет-странник", "strict": "строгий", "strongly": "сильно",
    "structure": "структура", "submerged": "погружённый", "succeeded": "удалось", "successful": "успешный",
    "suit": "костюм", "sulfur": "сера", "sulfuric": "серный", "supercritical": "сверхкритический",
    "supercritically": "сверхкритически", "superheated": "перегретый", "superheating": "перегрев",
    "support": "поддержка", "supported": "поддерживается", "surface": "поверхность", "sync": "синхронизация",
    "synced": "синхронизировано", "system": "система", "tablet": "планшет", "tablets": "планшеты",
    "tag": "тег", "tags": "теги", "take": "взять", "taken": "полученный", "takes": "занимает",
    "talkies": "рации", "tall": "высокий", "tank": "бак", "tanks": "баки", "target": "цель",
    "targets": "цели", "tech": "технология", "teleport": "телепорт", "teleportation": "телепортация",
    "teleported": "телепортирован", "teleporter": "телепорт", "temp": "температура", "temperature": "температура",
    "terracotta": "терракота", "thematically": "тематически", "thermal": "тепловой", "thermocouple": "термопара",
    "thermodynamic": "термодинамический", "thermoelectric": "термоэлектрический", "think": "думать",
    "things": "вещи", "threshold": "порог", "throughput": "пропускная способность", "tick": "тик",
    "ticks": "тики", "tier": "уровень", "tilling": "вспашка", "time": "время", "timers": "таймеры",
    "times": "раз", "tin": "олово", "tnt": "ТНТ", "together": "вместе", "tool": "инструмент",
    "tools": "инструменты", "total": "итого", "touch": "касание", "toughness": "стойкость",
    "towards": "к", "transfer": "передача", "transferred": "передано", "transmitter": "передатчик",
    "transmitters": "передатчики", "transparent": "прозрачный", "transporter": "транспортёр",
    "transporters": "транспортёры", "trapezoid": "трапеция", "travel": "путь", "treated": "обработан",
    "triangle": "треугольник", "trigger": "триггер", "trioxide": "триоксид", "true": "истина",
    "trying": "пытаясь", "tube": "труба", "tubes": "трубы", "turbine": "турбина", "turbines": "турбины",
    "turn": "ход", "turned": "включён", "two": "два", "type": "тип", "types": "типы", "ultimate": "абсолютный",
    "unbox": "распаковать", "unboxing": "распаковка", "uniform": "равномерный", "unit": "единица",
    "units": "единицы", "universal": "универсальный", "unspecified": "не задано", "until": "пока не",
    "upgrade": "улучшение", "upgrades": "улучшения", "upgrading": "улучшение", "upper": "верхний",
    "uranium": "уран", "usable": "пригодный", "usage": "использование", "use": "использовать",
    "used": "использовано", "user": "пользователь", "uses": "использует", "using": "используя",
    "valid": "допустимый", "value": "значение", "values": "значения", "vanilla": "ванильный",
    "vaporize": "испарять", "vaporized": "испарён", "variability": "разброс", "variants": "варианты",
    "various": "различные", "vein": "жила", "veins": "жилы", "vent": "сброс", "vented": "сброшено",
    "versa": "наоборот", "version": "версия", "vertically": "вертикально", "vibrations": "вибрации",
    "vibrator": "вибратор", "vice": "наоборот", "view": "вид", "viewer": "просмотр", "viewers": "просмотрщики",
    "viewing": "просмотр", "voice": "голос", "volume": "объём", "walkie": "рация", "want": "хотите",
    "warning": "предупреждение", "washer": "промывка", "washing": "промывка", "waste": "отходы",
    "water": "вода", "waterlogged": "затопленный", "weapon": "оружие", "weapons": "оружие",
    "weight": "вес", "well": "хорошо", "wide": "широкий", "wind": "ветер", "window": "окно",
    "windows": "окна", "wither": "иссушитель", "wood": "дерево", "wool": "шерсть", "working": "работа",
    "world": "мир", "worldwide": "глобально", "years": "годы", "zero": "ноль", "zombies": "зомби",
    "note": "примечание", "mb": "мБ", "fe": "FE", "fps": "FPS", "rgb": "RGB", "tcp": "TCP", "hud": "HUD",
    "gui": "интерфейс", "guis": "интерфейсы", "emc": "EMC", "cc": "CC", "ic": "IC", "prc": "PRC",
    "sna": "SNA", "sv": "SV", "tep": "TEP", "ex": "",
}

# Camel-case config identifiers that appear inside sentences stay as-is if unknown.
KEEP = {
    "mekanism", "minecraft", "qio", "sps", "fe", "fps", "rgb", "tcp", "emc", "prc", "tnt", "id",
    "hud", "mb",
}

TOKEN = re.compile(r"(%\d+\$s|%s|%\d+\$d|%d|§.|\\n)")
WORD_RE = re.compile(r"[A-Za-z][A-Za-z']*")


def protect(text):
    slots = []

    def repl(m):
        slots.append(m.group(0))
        return f"§§{len(slots)-1}§§"

    return TOKEN.sub(repl, text), slots


def restore(text, slots):
    for i, s in enumerate(slots):
        text = text.replace(f"§§{i}§§", s)
    return text


def apply_phrases(text):
    for src, dst in PHRASES:
        text = re.sub(re.escape(src), dst, text)
    for rx, dst in SHORT_TOKENS:
        text = rx.sub(dst, text)
    return text


def translate_words(text):
    def repl(m):
        raw = m.group(0)
        key = raw.lower().rstrip("'")
        if key in WORDS:
            return WORDS[key]
        # possessives
        if key.endswith("'s"):
            base = key[:-2]
            if base in WORDS:
                return WORDS[base]
        return raw

    return WORD_RE.sub(repl, text)


def tidy(text, original):
    text = re.sub(r"[ ]{2,}", " ", text).strip()
    text = re.sub(r"\s+([,.;:!?])", r"\1", text)
    if original[:1].isupper() and text[:1].islower():
        text = text[0].upper() + text[1:]
    return text


def translate(text, reuse):
    if text in reuse:
        return reuse[text]
    protected, slots = protect(text)
    protected = apply_phrases(protected)
    protected = translate_words(protected)
    return tidy(restore(protected, slots), text)


def leftover_words(text):
    found = []
    for w in WORD_RE.findall(text):
        key = w.lower().rstrip("'")
        if key in KEEP or key in WORDS:
            continue
        if key.endswith("s") and key[:-1] in WORDS:
            continue
        found.append(w)
    return found


def main():
    en_to_ru = {}
    loaded = []
    for en_path, ru_path in PAIRS:
        en = json.loads(en_path.read_text(encoding="utf-8"))
        ru = json.loads(ru_path.read_text(encoding="utf-8"))
        loaded.append((en_path, ru_path, en, ru))
        for k, v in en.items():
            if k in ru:
                en_to_ru.setdefault(v, ru[k])

    leftovers = {}
    for en_path, ru_path, en, ru in loaded:
        missing = 0
        ordered = {}
        if "_mekanism_force_utf8" in ru:
            ordered["_mekanism_force_utf8"] = ru["_mekanism_force_utf8"]
        for k, v in en.items():
            if k in ru:
                ordered[k] = ru[k]
            else:
                missing += 1
                ordered[k] = translate(v, en_to_ru)
                for w in leftover_words(ordered[k]):
                    leftovers.setdefault(w, 0)
                    leftovers[w] += 1
        # keep extra keys that are not in en (none expected)
        for k, v in ru.items():
            if k not in ordered:
                ordered[k] = v
        ru_path.write_text(json.dumps(ordered, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"{ru_path.name} parent={ru_path.parent.parent.parent.name} filled {missing} now {len([k for k in ordered if k in en])}/{len(en)}")

    print("leftover english words", len(leftovers))
    for w, c in sorted(leftovers.items(), key=lambda kv: -kv[1])[:80]:
        print(f"  {c:4} {w}")


if __name__ == "__main__":
    main()
